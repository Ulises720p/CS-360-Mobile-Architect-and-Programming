package com.example.mod3a1ulisesalmaguer;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView textGreeting;
    private EditText nameText;
    private Button buttonSayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializes the UI components by finding their IDs
        textGreeting = findViewById(R.id.textGreeting);
        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);

        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                buttonSayHello.setEnabled(!s.toString().trim().isEmpty());
            }



            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        buttonSayHello.setEnabled(!nameText.getText().toString().trim().isEmpty());
    }

// todo 06/12
    public void SayHello(View view) {
        String name = nameText.getText().toString();


        if (name != null && !name.trim().isEmpty()) {
            textGreeting.setText(getString(R.string.hello_greeting, name));
            Toast.makeText(this, "Greeting displayed!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, getString(R.string.empty_name_toast), Toast.LENGTH_SHORT).show();
        }
    }
}